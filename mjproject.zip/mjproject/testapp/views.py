from django.shortcuts import render
from testapp.models import hydjobs,blorejobs,chennaijobs,punejobs

# Create your views here

def index(request):
    return render(request,'testapp/index.html')
def hyd_jobs_view(request):
    jobs_list = hydjobs.objects.all()
    return render(request,'testapp/hydjobs.html',{'jobs_list':jobs_list})
def blore_jobs_view(request):
    #jobs_list=blorejobs.objects.all()
    jobs_list = blorejobs.objects.all()
    return render(request,'testapp/blorejobs.html',{'jobs_list':jobs_list})

def chennai_jobs_view(request):
    #jobs_list=chennaijobs.objects.all()
    jobs_list = chennaijobs.objects.all()
    return render(request,'testapp/chennaijobs.html',{'jobs_list':jobs_list})

def pune_jobs_view(request):
    #jobs_list=punejobs.objects.all()
    jobs4_list = punejobs.objects.all()
    return render(request,'testapp/punejobs.html',{'jobs_list':jobs4_list})
