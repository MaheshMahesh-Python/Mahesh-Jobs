from django.db import models

# Create your models here.
class hydjobs(models.Model):
    date=models.DateField(null='true');
    company=models.CharField(max_length=100,null='True');
    title=models.CharField(max_length=100,null='True');
    eligibility=models.CharField(max_length=100,null='True');
    address=models.CharField(max_length=100,null='True');
    email=models.EmailField(null='True');
    phonenumber=models.IntegerField(null='True')

class blorejobs(models.Model):
    date=models.DateField(null='True');
    company=models.CharField(max_length=100,null='True');
    title=models.CharField(max_length=100,null='True');
    eligibility=models.CharField(max_length=100,null='True');
    address=models.CharField(max_length=100,null='True');
    email=models.EmailField(null='True');
    phonenumber=models.IntegerField(null='True')

class chennaijobs(models.Model):
    date=models.DateField(null='True');
    company=models.CharField(max_length=100,null='True');
    title=models.CharField(max_length=100,null='True');
    eligibility=models.CharField(max_length=100,null='True');
    address=models.CharField(max_length=100,null='True');
    email=models.EmailField(null='True');
    phonenumber=models.IntegerField(null='True')

class punejobs(models.Model):
    date=models.DateField(null='True');
    company=models.CharField(max_length=100,null='True');
    title=models.CharField(max_length=100,null='True');
    eligibility=models.CharField(max_length=100,null='True');
    address=models.CharField(max_length=100,null='True');
    email=models.EmailField(null='True');
    phonenumber=models.IntegerField(null='True')
